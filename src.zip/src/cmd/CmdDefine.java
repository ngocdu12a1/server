package cmd;


public class CmdDefine {
    public static final short CUSTOM_LOGIN = 1;
    public static final short GET_USER_INFO = 1001;
   
    //Log cmd
    public static final short MOVE_OLD = 2001;
    public static final short GET_NAME = 2002;
    public static final short SET_NAME = 2003;

    public static final short UPDATE_STATUS = 2004;
    public static final short MOVE = 2005;
    public static final short RESET_MAP = 2006;
}
