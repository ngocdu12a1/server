package util.metric;


public class Metric {
    public static final String SEPE = "\t";
    public static final String DATE_FORMAT = "yyyy-MM-dd HH:mm:ss";
    public static final String NULL = "NULL";

    public Metric() {
        super();
    }
}
